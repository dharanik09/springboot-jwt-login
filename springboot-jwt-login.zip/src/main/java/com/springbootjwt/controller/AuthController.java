package com.springbootjwt.controller;

import com.springbootjwt.config.UserInfoUserDetails;
import com.springbootjwt.dto.AuthRequest;
import com.springbootjwt.dto.AuthResponse;
import com.springbootjwt.service.JwtService;
import com.springbootjwt.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private ProductService service;
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@RequestBody AuthRequest authRequest) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String testPasswordEncoded = passwordEncoder.encode(authRequest.getPassword());
        System.out.println(testPasswordEncoded);
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
        if (authentication.isAuthenticated()) {
           // return jwtService.generateToken(authRequest.getUsername());
        } else {
            throw new UsernameNotFoundException("invalid user request !");
        }

        SecurityContextHolder.getContext().setAuthentication(authentication);

        UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();

        //ResponseCookie jwtCookie = jwtService.generateJwtCookie(userDetails);

        List<String> roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());
        Map<String, String> jsonWebToken = new HashMap<>();
        AuthResponse authResponse = new AuthResponse(1, userDetails.getUsername(), roles , jwtService.generateToken(authRequest.getUsername()));
        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtService.generateToken(authRequest.getUsername()))
                .body(authResponse);
    }
}